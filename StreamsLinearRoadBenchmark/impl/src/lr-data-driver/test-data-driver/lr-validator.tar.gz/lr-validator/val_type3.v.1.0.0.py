import sys

# validate_type3.py: upload all type0 queries for validation output and solution output and compare them
# Usage: python validate_type3.py <validation_file> <solution_file>
# Or, this will simply be incorporated into the main validation script
if len(sys.argv) != 3:
	print "Usage: python validate_type0.py <validation_file> <solution_file>"

# Load validation file of type0 
val_dict = {} 
val_file = open(sys.argv[1])
for line in val_file:
	tokens = line.strip().split(',')	
	if tokens[0] == "3":  # Only pull type 3 toll notifications
		key = int(tokens[3])  # The key(int): qid[3].   The value(list:[int,float,int]): time[1],emit[2],balance[4]
		val_dict[key] = [int(tokens[1]),float(tokens[2]),int(tokens[4])]
#3,47,47.0000319481,11,21
#type,time,emit,qid,balance

# Verify count
print "Number of validation records: " + str(len(val_dict))

# Load solution file of type0
sol_dict = {} 
sol_file = open(sys.argv[2])
for line in sol_file:
	tokens = line.strip().split(',')	
	if tokens[0] == "3":  # Only pull type 3 toll notifications
		key = int(tokens[3]) # The key(int): qid[3].   The value(list:[int,float,int]): time[1],emit[2],balance[4]
		sol_dict[key] = [int(tokens[1]),float(tokens[2]),int(tokens[4])]

# Verfiy count
print "Number of solution records: " + str(len(sol_dict))

# Compare counts
if len(val_dict) == len(sol_dict):
	print "Counts check: PASSED"
else:
	print "Counts check: FAILED"

missing_from_validation = 0  # Found in validation file but not in solution
missed_time = 0  # Missed the time window
missed_balance = 0  # Missed balance
extra_in_solution = 0  # Found in solution but not in validation

for key in val_dict:
	if key not in sol_dict:
		missing = val_dict[key]
		print "-------------------------------------------------------"
		print "-\t3,"+str(missing[0])+","+str(missing[1])+","+str(key)+","+str(missing[2])
		print "-------------------------------------------------------"
		missing_from_validation += 1 
		# 100% is having none of these
	else:
		# Get the Values lists
		val_vals = val_dict[key]
		sol_vals = sol_dict[key]

		# Parse key for carid and time
		qid=key

		# Check emit time, but get it first
		process_time = float(sol_vals[1]) - float(sol_vals[0]) 
		if process_time > 10:  
			print "-------------------------------------------------------"
			print ">10\t3,"+str(sol_vals[0])+","+str(sol_vals[1])+","+str(qid)+","+str(sol_vals[2])
			print "-------------------------------------------------------"
			missed_time += 1

		# Check balance 
		if val_vals[2] != sol_vals[2]:
			print "-------------------------------------------------------"
			print "bal!=\t3,"+str(sol_vals[0])+","+str(sol_vals[1])+","+str(qid)+","+str(sol_vals[2])
			print "V bal\t3,"+str(val_vals[0])+","+str(val_vals[1])+","+str(qid)+","+str(val_vals[2])
			print "-------------------------------------------------------"
			missed_balance += 1
			


for key in sol_dict:
	if key not in val_dict:
		additional = sol_dict[key]
		print "-------------------------------------------------------"
		print "+\t3,"+str(additional[0])+","+str(additional[1])+","+str(key)+","+str(additional[2])
		print "-------------------------------------------------------"
		extra_in_solution += 1

# Need to decide how to weight all these
print "Missing from validation: " + str(missing_from_validation)
print "Missed time requirement: " + str(missed_time)
print "Missed balance amount: " + str(missed_balance)
print "Extra found in solution: " + str(extra_in_solution)
