import sys

# validate_type1.py: upload all type1 queries for validation output and solution output and compare them
# Usage: python val_type1.py <validation_file> <solution_file>
# Or, this will simply be incorporated into the main validation script
if len(sys.argv) != 3:
	print "Usage: python val_type1.py <validation_file> <solution_file>"

# Load validation file of type0 
val_dict = {} 
val_file = open(sys.argv[1])
for line in val_file:
	tokens = line.strip().split(',')	
	if tokens[0] == "1":  # Only pull type 1 toll notifications
		key = tokens[1]+","+tokens[3]+","+tokens[4]+","+tokens[5]+","+tokens[6]  # The key(string): time[1]-xway[3]-seg[4]-dir[5]-carid[6], Value: emit[2] 
		val_dict[key] = float(tokens[2])
#type,time,emit,xway,seg,dir,carid

# Verify count
print "Number of validation records: " + str(len(val_dict))

# Load solution file of type0
sol_dict = {} 
sol_file = open(sys.argv[2])
for line in sol_file:
	tokens = line.strip().split(',')	
	if tokens[0] == "1":  
		key = tokens[1]+","+tokens[3]+","+tokens[4]+","+tokens[5]+","+tokens[6]  # The key(string): time[1]-xway[3]-seg[4]-dir[5]-carid[6], Value: emit[2] 
		sol_dict[key] = float(tokens[2])

# Verfiy count
print "Number of solution records: " + str(len(sol_dict))

# Compare counts
if len(val_dict) == len(sol_dict):
	print "Counts check: PASSED"
else:
	print "Counts check: FAILED"

# Scores
missing_from_validation = 0  # Found in validation file but not in solution
missed_time = 0  # Missed the time window
extra_in_solution = 0  # Found in solution but not in validation

for key in val_dict:
	if key not in sol_dict:
		print "-------------------------------------------------------"
		print "-\t1," + key
		print "-------------------------------------------------------"
		missing_from_validation += 1
		# 100% is having none of these
	else:
		# Get the Values lists
		val_val = val_dict[key]
		sol_val = sol_dict[key]

		# Parse key for carid and time
		time,xway,seg,dir,carid=key.split(",")	

		# Check emit time, but get it first
		process_time = float(sol_val) - float(time) 
		if process_time > 5:  
			print "-------------------------------------------------------"
			print ">5\t1," + key + "," + str(sol_val) 
			print "-------------------------------------------------------"
			missed_time += 1

		# If the key exists, the rest of the values match

for key in sol_dict:
	if key not in val_dict:
		print "-------------------------------------------------------"
		print "+\t1," + key
		print "-------------------------------------------------------"
		extra_in_solution += 1

# Need to decide how to weight all these
print "Missing from validation: " + str(missing_from_validation)
print "Missed time requirement: " + str(missed_time)
print "Extra found in solution: " + str(extra_in_solution)
