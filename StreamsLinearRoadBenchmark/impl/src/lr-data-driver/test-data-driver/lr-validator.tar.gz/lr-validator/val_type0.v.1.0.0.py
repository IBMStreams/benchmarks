import sys

# validate_type0.py: upload all type0 queries for validation output and solution output and compare them
# Usage: python validate_type0.py <validation_file> <solution_file>
# Or, this will simply be incorporated into the main validation script
if len(sys.argv) != 3:
	print "Usage: python validate_type0.py <validation_file> <solution_file>"

# Load validation file of type0 
val_dict = {} 
val_file = open(sys.argv[1])
for line in val_file:
	tokens = line.strip().split(',')	
	if tokens[0] == "0":  # Only pull type 0 toll notifications
		key = tokens[1]+","+tokens[2]  # The key(string): carid[1]-time[2].   The value(list:[int,float,int]): emit[3],LAV[4],toll[5]
		val_dict[key] = [float(tokens[3]),int(tokens[4]),int(tokens[5])]

# Verify count
print "Number of validation records: " + str(len(val_dict))

# Load solution file of type0
sol_dict = {} 
sol_file = open(sys.argv[2])
for line in sol_file:
	tokens = line.strip().split(',')	
	if tokens[0] == "0":  #  Same as above, although this should be moot if the outfile only contains type 0 toll notifications
		key = tokens[1]+","+tokens[2]  
		sol_dict[key] = [float(tokens[3]),int(tokens[4]),int(tokens[5])]

# Verfiy count
print "Number of solution records: " + str(len(sol_dict))

# Compare counts
if len(val_dict) == len(sol_dict):
	print "Counts check: PASSED"
else:
	print "Counts check: FAILED"

# Scores
missing_from_validation = 0  # Found in validation file but not in solution
missed_time = 0  # Missed the time window
missed_lav = 0  # Missed lav (but is this important?)
missed_toll = 0  # Missed toll amount
extra_in_solution = 0  # Found in solution but not in validation

for key in val_dict:
	if key not in sol_dict:
		print "-------------------------------------------------------"
		print "-\t0," + key + "," +  ",".join(map(str,val_dict[key]))
		print "-------------------------------------------------------"
		missing_from_validation += 1
		# 100% is having none of these
	else:
		# Get the Values lists
		val_vals = val_dict[key]
		sol_vals = sol_dict[key]

		# Parse key for carid and time
		carid,time=key.split(",")	

		# Check emit time, but get it first
		process_time = float(sol_vals[0]) - float(time) 
		if process_time > 5:  
			print "-------------------------------------------------------"
			print ">5\t0," + key + "," + ",".join(map(str,sol_dict[key]))
			print "-------------------------------------------------------"
			missed_time += 1

		# Check lav value
		if val_vals[1] != sol_vals[1]:
			print "-------------------------------------------------------"
			print "!=lav\t0," + key + "," + ",".join(map(str,sol_dict[key]))
			print "V lav\t0," + key + "," + ",".join(map(str,val_dict[key]))
			print "-------------------------------------------------------"
			missed_lav += 1
			
		# Check toll value
		if val_vals[2] != sol_vals[2]:
			print "-------------------------------------------------------"
			print "!=val\t0," + key + "," + ",".join(map(str,sol_dict[key]))
			print "V val\t0," + key + "," + ",".join(map(str,val_dict[key]))
			print "-------------------------------------------------------"
			missed_toll += 1


for key in sol_dict:
	if key not in val_dict:
		print "-------------------------------------------------------"
		print "+\t0," + key + "," + ",".join(map(str,sol_dict[key]))
		print "-------------------------------------------------------"
		extra_in_solution += 1	


# Need to decide how to weight all these
print "Missing from validation: " + str(missing_from_validation)
print "Missed time requirement: " + str(missed_time)
print "Missed LAV calculation: " + str(missed_lav)
print "Missed Toll amount: " + str(missed_toll)
print "Extra found in solution: " + str(extra_in_solution)
