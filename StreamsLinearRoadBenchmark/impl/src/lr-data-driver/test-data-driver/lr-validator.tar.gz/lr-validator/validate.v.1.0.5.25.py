import time, sys, sets 

# CHANGES FOR v.1.0.5.24
# BASED ON v.1.0.5.19
# Add proper type 2 processing to output alternative type2 values to a separate file

pos_reports = {}  # key: type+time+carid; values: [speed, xway, lane, dir]
cars = {}  # key: carid; values: [time[0], speed[1], xway[2], lane[3], dir[4], seg[5], pos[6], xpos[7], ltoll[8], bal[9], bal1[10], bal2[11]]  # All the car values represent the _last_ or _previous_ car stats
# v.1.0.5.8: change seg to hold long(total_speeds) and calc from real value, no reconstitution
#segs = {}  # key: xway+seg+dir+min: values: [lav[0], numv[1], numv4lav[2]]  # seg data is only relevant on this key
segs = {}  # key: xway+seg+dir+min: values: [sum_speeds[0], numv[1], numv4lav[2]]  # seg data is only relevant on this key
stopped = {}  # key: xway+lane+dir+seg+pos; values [carid...]  # a list of carids
accidents = {}  # key:xway+lane+dir+seg; values: [time, clear_time, carid1, carid2, ...]  # moving forward with only two cars can be part of an accident (we'll see if the mitsim data holds)
tolls = {} # key: carid; values: [time,toll],[time,toll],...

outfile = open(sys.argv[3],"w")


num_t0out = 0
num_t1out = 0
num_t2out = 0
num_t3out = 0
num_noise = 0

###########################################################
# Calculate the toll
###########################################################
def calctoll(numv):
	return 2 * (50-numv)**2	

###########################################################
# Update a field in a list in a map
###########################################################
def update(d, key, index, nv):  # (dict, key, index, newvalue) -- index assuming the value of this dict is a list, which it is in our case
	d[key][index] = nv

###########################################################
# Print current stopped cars 
###########################################################
def print_stopped():
	print "###########################################"
	print "STOPPED"
	#print stopped 
	print "NUM STOPPED: " + str(len(stopped))
	print "###########################################"
###########################################################
# Print current accidents 
###########################################################
def print_accidents():
	print "###########################################"
	print "ACCIDENTS"
	print accidents
	print "NUM ACCIDENTS: " + str(len(accidents))
	print "###########################################"

#############################################################	
# Process type 0 reports 
#############################################################	
def t0(t):
	starttime = time.time()
	# Create these two keys for potential use
	stopped_key = t[4]+"-"+t[5]+"-"+t[6]+"-"+t[7]+"-"+t[8]  # xway[4], lane[5], dir[6], seg[7], pos[8] # Keep this, and other multi-field keys as strings
	accident_key = t[4]+"-"+t[6]+"-"+t[7]  # xway[4], dir[6], seg[7]  # The lane is not important
	ptime = int(t[1])  # Change the other fields to ints to save space ... and maybe allow faster processing
	carid = int(t[2])
	speed = int(t[3])
	xway  = int(t[4])
	lane  = int(t[5])
	dir   = int(t[6])
	seg   = int(t[7])
	pos   = int(t[8])

	min = ptime/60+1
	seg_key = str(xway)+"-"+str(seg)+"-"+str(dir)+"-"+str(min)  
	if seg_key not in segs:  # If we don't have any stats yet for this segment, simply enter them 
		#segs[seg_key] = [speed, 1, 1]
		#segs[seg_key] = [0,1,0, set([])] 
		segs[seg_key] = [0,0,0, set([])] 
	last_toll = 0
	curr_toll = 0
	new_seg_flag = False
	car = None
	#######################################################################################################
	# DOES CAR ALREADY EXIST IN DATA SET?  if not, enter with deafult values, if so get the car
	#######################################################################################################
	if carid not in cars:
		# Eliminate "noise" of type-0, lane-4 without any previous entry
		if lane == 4:
			print "Noise"
			global num_noise
			num_noise += 1
			return
			
		cars[carid] = [-100, -100, -100, -100, -100, -100, -100, 0, 0, 0, 0, 0] 
	else:
		# Check if re-entrant
		# When a car re-enters it is like a new car EXCEPT the balance(s).  That and the carid are the only things that will remain.
		if  lane == 0 and ptime > cars[carid][0] + 60:  # The ptime should always be 30 > than the previous, except for re-entrants 
			car = cars[carid]
			cars[carid] = [-100, -100, -100, -100, -100, -100, -100, 0, 0, car[9], car[10], car[11]] 
		#else if last lane seen was 4 but this one isn't 0, then ignore
		elif cars[carid][3] == 4 and lane != 0:
			return  # every data point after an exit, unless it's an entry, is ignored
		#else process a normal non-entrant, non-exit position report

	car = cars[carid]
	last_toll = car[8]
	########################################################################################
	# IS THIS CAR IN THE SAME POSITION AS IT WAS IN THE PREVIOUS REPORT?
	########################################################################################
	if car[6] == pos and car[2] == xway and car[4] == dir and car[3] == lane:	
		# Check if this is a stopped car, i.e. this is the fourth consecutive report in the same pos
		if car[7] >= 3:  # Meaning, _this_ is at least the fourth time, and 3 or greater was the last time
			###################################################################
			# CREATE A STOPPED CAR 
			###################################################################
			if stopped_key not in stopped:
				stopped[stopped_key] = [carid]
				print_stopped()
			if stopped_key in stopped and carid not in stopped[stopped_key]:
				print "Adding a car to a stopped car location"
				stopped[stopped_key].append(carid)
			###################################################################
			# CREATE AN ACCIDENT
			###################################################################
			# accident_key = t[4]+"-"+t[6]+"-"+t[7]  # xway[4], dir[6], seg[7]  # The lane is not important, but we need time!
			stopped_cars = stopped[stopped_key]
			len_stopped = len(stopped_cars)
			# If there are more than one stopped cars at this pos, throw an error
			if len_stopped > 1: # If there are two cars at this stopped_key 
				if accident_key not in accidents:  # If there isn't already an accident
					accidents[accident_key] = [ptime, -1] 
					print_accidents()
				for c in stopped_cars:
					if c not in accidents[accident_key]:
						accidents[accident_key].append(c)
						print_accidents()
		update(cars, carid, 7, car[7]+1) 
	##########################################################################
	# NEW POS FOR CAR, NOT NECESSARILY NEW SEGMENT
	##########################################################################
	else:
		###########################################################
		# REMOVE STOPPED CAR from stopped if it's there
		###########################################################
		temp_key = str(xway)+"-"+str(car[3])+"-"+str(dir)+"-"+str(car[5])+"-"+str(car[6])
		removed_stopped_flag = False #D 
		if temp_key in stopped:
			print stopped[temp_key]
			print carid
			print "Removing " + str(carid) + " from stopped"
			if carid in stopped[temp_key]: # You actually have overlap with non-stopped cars, so you have to account for it
				stopped[temp_key].remove(carid)
			if len(stopped[temp_key]) == 0:
				print "Removing stopped key " + temp_key
				#stopped.pop(temp_key)
				del stopped[temp_key]
				removed_stopped_flag = True
		update(cars, carid, 7, 1) 
		###########################################################
		# CLEAR ACCIDENT IF ANY INVOLVING THIS CAR
		###########################################################
		temp_key = str(car[2])+"-"+str(car[4])+"-"+str(car[5])  # And, can you have ANOTHER accident at the same key?  Clear after a minute?
		removed_accident_flag = False  #D
		#print_accidents()
		if temp_key in accidents:
			accident = accidents[temp_key]
			if accident[1] == -1 and (carid == accident[2] or carid == accident[3]):   # Clear if ONLY one of the original two cars moves
				#accidentst[1] = ptime  # No longer removing an accident, but setting a time greater than -1 to indicate clearance time 
				accidents[temp_key][1] = ptime  # No longer removing an accident, but setting a time greater than -1 to indicate clearance time 
				removed_accident_flag = True  #D
		if removed_accident_flag == True:  #D
			print_accidents()

		# SAME SEGMENT (and xway and dir)
		if car[5] == seg and car[2] == xway and car[4] == dir:
			if lane == 4:
				# set last lane seen as 4
				update(cars, carid, 3, 4) 
				#return
		#######################################################################################################################
		#######################################################################################################################
		# NEW SEGMENT: check for upstream accidents, calculate and send toll notification, update seg stats, assess toll from previous seg if any 
		#######################################################################################################################
		#######################################################################################################################
		else: 	
			print "NEW SEGMENT for " + str(carid)
			new_seg_flag = True
			##############################################################
			# TOLL CALCULATION 
			##############################################################
			numv = 1  # initial assumed number of vehicles and speeds in the segment
			total_speed = 0  # The sum of all speeds 
			total_speed_readings = 0 
			lav_keys = []
			lav = 0
			######################################################
			# GET NUMV  (remember, from last 1 minute)		
			######################################################
			last_min_key = str(xway)+"-"+str(seg)+"-"+str(dir)+"-"+str(min - 1)  # Gather data from the last full minute if it exists
			if last_min_key in segs:  # If we're just starting this key won't exist since it will be min = 0 
				#numv = segs[last_min_key][1]
				numv = len(segs[last_min_key][3])
				#print "NUMV for seg " + last_min_key + " in the last minute is " + str(numv)
				print "NUMV for seg (SET) " + last_min_key + " in the last minute is " + str(len(segs[last_min_key][3]))
				curr_toll = calctoll(numv)	
				print "POTENTIAL TOLL FROM NUMV: " + str(curr_toll)
				if numv <= 50: 
					curr_toll = 0
			######################################################
			# GET LAV (remember, from last 5 minutes) 
			######################################################
			for i in xrange(1,6):
				lav_keys.append(str(xway)+"-"+str(seg)+"-"+str(dir)+"-"+str(min-i))
			for akey in lav_keys:
				if akey in segs: 
					total_speed += segs[akey][0]  # may need round to int to avoid creeping errors		
					total_speed_readings += segs[akey][2]
					print "TOTAL_SPEED: " + str(total_speed) + " and TOTAL_SPEED_READINGS " + str(total_speed_readings)
			if total_speed_readings > 0:
				lav = total_speed / float(total_speed_readings)
				print "LAV for segs " + ','.join(lav_keys) + " in the last minute is " + str(lav) 
				if int(round(lav)) >= 40:  
					curr_toll = 0  
			##################################################################
			# CHECK FOR UPSTREAM ACCIDENTS 
			##################################################################
			accident_keys = []
			if dir == 0:
				for i in xrange(0,5):
					accident_keys.append(str(xway)+"-"+str(dir)+"-"+str(seg+i))
			else:
				for i in xrange(0,5):
					accident_keys.append(str(xway)+"-"+str(dir)+"-"+str(seg-i))
			# Check for accidents
			for akey in accident_keys:
				if akey in accidents:	
					acc_seg = akey.split("-")[2]
					accident = accidents[akey]
					car_min = ptime/60 + 1
					acc_noti_threshold_min = accident[0]/60 + 2
					acc_clear_min = accident[1]/60 + 1
					# The check for accidents in the same minute
					if accident[1] != -1 and acc_noti_threshold_min > acc_clear_min: # if accident is cleared and time requirements are not met...
						continue
					if (lane != 4 and
					    ((car_min >= acc_noti_threshold_min and accident[1]==-1) or 
					    (car_min <= acc_clear_min and accident[1]!=-1))) :
						curr_toll = 0
						#############################################################	
						#############################################################	
						# WRITE OUT THE ACCIDENT NOTIFICATION! 
						#############################################################	
						#############################################################	
						outfile.write("1,"+str(ptime)+","+str(ptime+(time.time()-starttime))+","+str(xway)+","+str(acc_seg)+","+str(dir)+","+str(carid)+"\n")
						print "OUTPUT TYPE 1: 1,"+str(ptime)+","+str(ptime+(time.time()-starttime))+","+str(xway)+","+str(acc_seg)+","+str(dir)+","+str(carid)
						global num_t1out
						num_t1out += 1
						break

			############################################################
			# ASSESS PREVIOUS TOLL if any (before or after notification?)
			############################################################
			if car[8] > 0: # Remember, this is the toll from a previous segment
				# If you want to keep the last three balances, for the sake of "result time," move them down
				car[11] = car[10] # balance at time - 60
				car[10] = car[9]  # balance at time - 30 
				# Add the PREVIOUS 'toll' to the balance of the car, [9].  
				cars[carid][9] += cars[carid][8] # Remember, we're assessing the _last_ toll, not the current toll!	
				if carid in tolls:
					#tolls[carid].append(car[8])
					tolls[carid].append([ptime,car[8]])
				else:
					#tolls[carid] = [car[8]]
					tolls[carid] = [[ptime,car[8]]]
			##############################################
			# LASTLY, if EXIT LANE, then NO notification is sent!  
			##############################################
			if lane != 4:
				#############################################################	
				#############################################################	
				# WRITE OUT THE TOLL NOTIFICATION! 
				#############################################################	
				#############################################################	
				outfile.write("0,"+str(carid)+","+str(ptime)+","+str(ptime+(time.time()-starttime))+","+str(int(round(lav)))+","+str(curr_toll)+"\n")  # little bugs
				print "OUTPUT TYPE 0: 0,"+str(carid)+","+str(ptime)+","+str(ptime+(time.time()-starttime))+","+str(int(round(lav)))+","+str(curr_toll)
				global num_t0out
				num_t0out += 1


	########################################################
	# UPDATE CAR STATS, BY THE MINUTE
	########################################################
	car = cars[carid]
	car[0] = ptime
	car[1] = speed
	car[2] = xway
	car[3] = lane
	car[4] = dir
	car[5] = seg
	car[6] = pos
	if new_seg_flag:
		car[8] = curr_toll 
	else:
		car[8] = last_toll 

	########################################################
	# UPDATE SEG STATS, by the MINUTE
	########################################################
	if seg_key in segs:  # Pull and update values
		curr_seg = segs[seg_key]
		if new_seg_flag:  # numv
			curr_seg[1] += 1
		curr_seg[2] += 1  # numv4lav
		curr_seg[0] += speed
		curr_seg[3].add(carid)
		segs[seg_key] = curr_seg

	########################################################
	# REMOVE SEGS NO LONGER RELEVANT
	########################################################
	old_seg_key = str(xway)+"-"+str(seg)+"-"+str(dir)+"-"+str(min-7)  
	if old_seg_key in segs:  # 
		del segs[old_seg_key]
		

#############################################################	
# Process type 2 reports 
#############################################################	
# This will give up to, but not necessarily, three different values
# Values will be t, t-30, or t-60
# And, since there is no necessity that a car changes segments during this time all the values could be the same
def t2(t): 
	starttime = time.time()
	print t	
	ptime = int(t[1])  # Change the other fields to ints to save space ... and maybe allow faster processing
	carid = int(t[2])
	speed = int(t[3])
	xway  = int(t[4])
	lane  = int(t[5])
	dir   = int(t[6])
	seg   = int(t[7])
	pos   = int(t[8])
	qid   = int(t[9])

	bal0 = 0 
	bal1 = 0 

	rt0 = ptime 
	rt1 = 0

	c1 = [] 

	if carid in tolls:
		charges = tolls[carid]
		ncharges = len(charges)

		# The actual  
		for charge_tuple in charges:
			bal0 += charge_tuple[1]
			#rt0 = charge_tuple[0] 

		# Subtract the most recent charge  
		if ncharges > 1:
			c1 = charges[ncharges-1]  
			rt1 = ptime-30 
			bal1 = bal0 - c1[1]

	#############################################################	
	#############################################################	
	# WRITE OUT THE TYPE 2 NOTIFICATION! 
	#############################################################	
	#############################################################	
	outfile.write("2,"+str(ptime)+","+str(ptime+(time.time()-starttime))+","+str(rt0)+","+str(qid)+","+str(bal0) +"\n")
	outfile.write("5,"+str(ptime)+","+str(ptime+(time.time()-starttime))+","+str(rt1)+","+str(qid)+","+str(bal1)+"\n")
	print "OUTPUT TYPE 2: 2,"+str(ptime)+","+str(ptime+(time.time()-starttime))+","+str(rt0)+","+str(qid)+","+str(bal0)
	print "OUTPUT TYPE 2: 5,"+str(ptime)+","+str(ptime+(time.time()-starttime))+","+str(rt1)+","+str(qid)+","+str(bal1)
	global num_t2out
	num_t2out += 1




#############################################################	
# Process type 3 reports 
#############################################################	
# This dict will hold the historical tolls information
# [carid, day, xway, amt]
# key: carid, day, xway; value: amt
historical = {}
history = open(sys.argv[2])
for h in history:
	t = h.strip().split(',')
	key = t[0]+"-"+t[1]+"-"+t[2]
	historical[key] = t[3] 

def t3(t):
	starttime = time.time()
	ptime = t[1]  
	carid = t[2]
	speed = t[3]
	xway  = t[4]
	lane  = t[5]
	dir   = t[6]
	seg   = t[7]
	pos   = t[8]
	qid   = t[9]
	day   = t[14]

	key = carid+"-"+day+"-"+xway
	dtoll = '0'
	if key in historical and day != 0: 	
		dtoll = historical[key]
		#############################################################	
		#############################################################	
		# WRITE OUT THE TYPE 3 NOTIFICATION! 
		#############################################################	
		#############################################################	
		outfile.write("3,"+ptime+","+str(int(ptime)+(time.time()-starttime))+","+qid+","+dtoll+"\n")
		print "OUTPUT TYPE 3: 3,"+ptime+","+str(int(ptime)+(time.time()-starttime))+","+qid+","+dtoll
		global num_t3out
		num_t3out += 1


# Main
positions = open(sys.argv[1])

# Keep counts of how many of each type we see
num_t0 = 0
num_t2 = 0
num_t3 = 0
num_t4 = 0
# Keep a map of type 2's coming in and process after the second
type2s = {}  # {time: [[],[]]}
curr_time = '0'  # use to keep track of the current time for type 2 processing
type2s[curr_time] = []

for report in positions:
	t = report.strip().split(",")

	if t[0] == '0':
		t0(t)
		num_t0 += 1
	elif t[0] == '2':
		# And this is where things change a touch in v24
		if t[1] != curr_time: 
			print "type 2 time change: " + curr_time + " to " + t[1] 
			ntype2 = 0
			if curr_time in type2s:
				for tup in type2s[curr_time]:
					t2(tup)
					ntype2 += 1
				del type2s[curr_time]
				print "Processed " + str(ntype2) + " type2 reports for time " + curr_time + " at time " + t[1]
		if t[1] in type2s:
			type2s[t[1]].append(t)
		else:
			type2s[t[1]] = [t]
		num_t2 += 1
		curr_time = t[1]  # current type2 time
	elif t[0] == '3':
		t3(t)
		num_t3 += 1
	elif t[0] == '4': 
		num_t4 += 1

# Type 2 clean up
ntype2 = 0
for k in type2s:
	for tup in type2s[k]:
		t2(tup)
		ntype2 += 1
print "Processed " + str(ntype2) + " type2 reports for time " + curr_time + " at time " + t[1]
	

print "Number of type 0 processed: " + str(num_t0)	
print "Number of type 2 processed: " + str(num_t2)	
print "Number of type 3 processed: " + str(num_t3)	
print "Number of type 4 seen: " + str(num_t4)	

######################################################
# Report how many of each report was created
######################################################
print "Number of type 0 toll notifications sent: " + str(num_t0out)
print "Number of type 1 accident reports: " + str(num_t1out) 
print "Number of type 2 balance queries: " + str(num_t2out) 
print "Number of type 3 historical balance queries: " + str(num_t3out)
print "Number of 'noise' entries seen: " + str(num_noise)	


