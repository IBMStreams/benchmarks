#!/bin/bash

# validate.sh: take the validate.py script output, split the output into four files, take the solution output and split into four files and compare
# Usage: ./validate.sh <validation output> <solution output>

validation=$1
solution=$2

if [[ ! $# -eq 2 ]]; then
	echo "Usage: ./validate.sh <validation output> <solution output>"
	exit 1
fi 

echo "Spliting output files"
time python split_val_and_sol.v.1.0.2.py $1 $2

echo "Validing type 0 output"
time python val_type0.v.1.0.0.py val.temp.0 sol.temp.0

echo "Validing type 1 output"
time python val_type1.v.1.0.0.py val.temp.1 sol.temp.1

echo "Validing type 2 output"
time python val_type2.v.1.0.2.py val.temp.2 sol.temp.2

echo "Validing type 3 output"
time python val_type3.v.1.0.0.py val.temp.3 sol.temp.3
