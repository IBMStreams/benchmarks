import sys

# split_val_and_sol.py: split out validation and solution output into typed files
# Usage: python split_val_and_sol.py <validation output> <solution output>

valfile = open(sys.argv[1])
solfile = open(sys.argv[2])

valfile0 = open('val.temp.0','w')
valfile1 = open('val.temp.1','w')
valfile2 = open('val.temp.2','w')
valfile3 = open('val.temp.3','w')
solfile0 = open('sol.temp.0','w')
solfile1 = open('sol.temp.1','w')
solfile2 = open('sol.temp.2','w')
solfile3 = open('sol.temp.3','w')

for line in valfile:
	t = line.strip().split(",")
	if t[0] == '0':
		valfile0.write(line)
	elif t[0] == '1':	
		valfile1.write(line)
	elif t[0] == '2' or t[0] == '5':	
		valfile2.write(line)
	elif t[0] == '3':	
		valfile3.write(line)

for line in solfile:
	t = line.strip().split(",")
	if t[0] == '0':
		solfile0.write(line)
	elif t[0] == '1':	
		solfile1.write(line)
	elif t[0] == '2':	
		solfile2.write(line)
	elif t[0] == '3':	
		solfile3.write(line)

valfile0.close()
valfile1.close()
valfile2.close()
valfile3.close()
solfile0.close()
solfile1.close()
solfile2.close()
solfile3.close()

valfile.close()
solfile.close()
